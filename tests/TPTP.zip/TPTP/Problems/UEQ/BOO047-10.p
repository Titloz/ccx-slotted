%------------------------------------------------------------------------------
% File     : BOO047-10 : TPTP v9.0.0. Released v7.3.0.
% Domain   : Puzzles
% Problem  : Single axiom C8 for Boolean algebra in the Sheffer stroke
% Version  : Especial.
% English  :

% Refs     : [CS18]  Claessen & Smallbone (2018), Efficient Encodings of Fi
%          : [Sma18] Smallbone (2018), Email to Geoff Sutcliffe
% Source   : [Sma18]
% Names    :

% Status   : Open
% Rating   : 1.00 v7.3.0
% Syntax   : Number of clauses     :    2 (   2 unt;   0 nHn;   1 RR)
%            Number of literals    :    2 (   2 equ;   1 neg)
%            Maximal clause size   :    1 (   1 avg)
%            Maximal term depth    :    5 (   2 avg)
%            Number of predicates  :    1 (   0 usr;   0 prp; 2-2 aty)
%            Number of functors    :    5 (   5 usr;   3 con; 0-2 aty)
%            Number of variables   :    3 (   1 sgn)
% SPC      : CNF_OPN_RFO_PEQ_UEQ

% Comments : Converted from BOO047-1 to UEQ using [CS18].
%------------------------------------------------------------------------------
cnf(c8,axiom,
    nand(nand(nand(A,nand(A,B)),A),nand(B,nand(C,A))) = B ).

cnf(prove_meredith_2_basis,negated_conjecture,
    tuple(nand(a,nand(b,nand(a,c))),nand(nand(a,a),nand(b,a))) != tuple(nand(nand(nand(c,b),b),a),a) ).

%------------------------------------------------------------------------------
