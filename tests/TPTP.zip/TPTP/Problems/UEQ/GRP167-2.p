%--------------------------------------------------------------------------
% File     : GRP167-2 : TPTP v9.0.0. Bugfixed v1.2.1.
% Domain   : Group Theory (Lattice Ordered)
% Problem  : Product of positive and negative parts
% Version  : [Fuc94] (equality) axioms : Augmented.
% English  : Each element in a lattice ordered group can be stated as a
%            product of it's positive and it's negative part.

% Refs     : [Fuc94] Fuchs (1994), The Application of Goal-Orientated Heuri
%          : [Sch95] Schulz (1995), Explanation Based Learning for Distribu
% Source   : [Sch95]
% Names    : lat4 [Sch95]

% Status   : Unsatisfiable
% Rating   : 0.27 v8.2.0, 0.33 v8.1.0, 0.25 v7.4.0, 0.39 v7.3.0, 0.32 v7.1.0, 0.22 v7.0.0, 0.26 v6.4.0, 0.32 v6.3.0, 0.35 v6.2.0, 0.43 v6.1.0, 0.44 v6.0.0, 0.57 v5.5.0, 0.58 v5.4.0, 0.40 v5.3.0, 0.33 v5.2.0, 0.36 v5.1.0, 0.33 v5.0.0, 0.29 v4.1.0, 0.27 v4.0.1, 0.21 v4.0.0, 0.23 v3.7.0, 0.22 v3.4.0, 0.25 v3.3.0, 0.21 v3.1.0, 0.11 v2.7.0, 0.09 v2.6.0, 0.17 v2.5.0, 0.00 v2.4.0, 0.00 v2.2.1, 0.33 v2.2.0, 0.57 v2.1.0, 0.71 v2.0.0
% Syntax   : Number of clauses     :   23 (  23 unt;   0 nHn;   2 RR)
%            Number of literals    :   23 (  23 equ;   1 neg)
%            Maximal clause size   :    1 (   1 avg)
%            Maximal term depth    :    3 (   2 avg)
%            Number of predicates  :    1 (   0 usr;   0 prp; 2-2 aty)
%            Number of functors    :    8 (   8 usr;   2 con; 0-2 aty)
%            Number of variables   :   44 (   2 sgn)
% SPC      : CNF_UNS_RFO_PEQ_UEQ

% Comments : ORDERING LPO inverse > greatest_lower_bound >
%            least_upper_bound > product > negative_part > positive_part >
%            identity > a
% Bugfixes : v1.2.1 - Duplicate axioms in GRP004-2.ax removed.
%--------------------------------------------------------------------------
%----Include equality group theory axioms
include('Axioms/GRP004-0.ax').
%----Include Lattice ordered group (equality) axioms
include('Axioms/GRP004-2.ax').
%--------------------------------------------------------------------------
cnf(lat4_1,axiom,
    inverse(identity) = identity ).

cnf(lat4_2,axiom,
    inverse(inverse(X)) = X ).

cnf(lat4_3,axiom,
    inverse(multiply(X,Y)) = multiply(inverse(Y),inverse(X)) ).

cnf(lat4_4,axiom,
    positive_part(X) = least_upper_bound(X,identity) ).

cnf(lat4_5,axiom,
    negative_part(X) = greatest_lower_bound(X,identity) ).

cnf(lat4_6,axiom,
    least_upper_bound(X,greatest_lower_bound(Y,Z)) = greatest_lower_bound(least_upper_bound(X,Y),least_upper_bound(X,Z)) ).

cnf(lat4_7,axiom,
    greatest_lower_bound(X,least_upper_bound(Y,Z)) = least_upper_bound(greatest_lower_bound(X,Y),greatest_lower_bound(X,Z)) ).

cnf(prove_lat4,negated_conjecture,
    a != multiply(positive_part(a),negative_part(a)) ).

%--------------------------------------------------------------------------
